module com.mycompany.layouttesting {
    requires javafx.controls;
    exports App;
}
