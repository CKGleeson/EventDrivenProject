package Server.View;

import Server.Controller.LectureSchedulerServer;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

/**
 * The GUI view for displaying server status, connected clients, and logs.
 * Includes disconnect buttons for each connected client.
 */
public class ServerStatusView {
    private Stage primaryStage;
    private ListView<String> logView = new ListView<>();
    private ListView<ClientEntry> clientListView = new ListView<>();
    private Label statusLabel = new Label("Server Status: Not Running");
    private Label clientCountLabel = new Label("Connected Clients: 0");
    private Button closeButton = new Button("Close Server");
    private Map<String, ClientEntry> clientEntries = new HashMap<>();
    private int clientCounter = 0;

    private static class ClientEntry {
        final String id;
        final String info;
        boolean connected;
        
        ClientEntry(String id, String info, boolean connected) {
            this.id = id;
            this.info = info;
            this.connected = connected;
        }
        
        @Override
        public String toString() {
            return id + " (" + info + "): " + (connected ? "CONNECTED" : "DISCONNECTED");
        }
    }

    /**
     * Starts and displays the server status window.
     * @param stage The primary stage for the application
     */
    public void start(Stage stage) {
        primaryStage = stage;
        setupUI();
        setupEventHandlers();
        
        Scene scene = new Scene(createRootLayout(), 650, 550);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Lecture Scheduler Server Console");
        primaryStage.show();
    }

    private void setupUI() {
        logView.setPrefHeight(350);
        clientListView.setPrefHeight(200);
        statusLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        clientCountLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12px;");
        closeButton.setStyle("-fx-base: #d9534f; -fx-text-fill: white;");
        
        // Custom cell factory for client list with disconnect buttons
        clientListView.setCellFactory(param -> new ListCell<ClientEntry>() {
            private final HBox container = new HBox();
            private final Label label = new Label();
            private final Button disconnectBtn = new Button("Disconnect");
            
            {
                container.setSpacing(10);
                container.getChildren().addAll(label, disconnectBtn);
                HBox.setHgrow(label, Priority.ALWAYS);
                disconnectBtn.setStyle("-fx-base: #d9534f; -fx-text-fill: white;");
                
                disconnectBtn.setOnAction(event -> {
                    ClientEntry entry = getItem();
                    if (entry != null && entry.connected) {
                        LectureSchedulerServer.disconnectClient(entry.info);
                    }
                });
            }
            
            @Override
            protected void updateItem(ClientEntry item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                } else {
                    label.setText(item.toString());
                    disconnectBtn.setVisible(item.connected);
                    setGraphic(container);
                }
            }
        });
    }

    private VBox createRootLayout() {
        VBox root = new VBox(10);
        root.setPadding(new javafx.geometry.Insets(15));
        root.getChildren().addAll(
            statusLabel,
            clientCountLabel,
            new Label("Client Connections:"),
            clientListView,
            new Label("Server Log:"),
            logView,
            closeButton
        );
        return root;
    }

    private void setupEventHandlers() {
        closeButton.setOnAction(e -> shutdownServer());
        primaryStage.setOnCloseRequest(this::handleWindowClose);
    }

    private void handleWindowClose(WindowEvent event) {
        event.consume();
        shutdownServer();
    }

    private void shutdownServer() {
        Platform.runLater(() -> {
            log("Server shutdown initiated");
            statusLabel.setText("Server Status: Shutting down...");
        });
        LectureSchedulerServer.stopServer();
    }
    
    /**
     * Adds a new client to the connected clients list.
     * @param clientInfo The client's connection information (IP:PORT)
     */
    public void clientConnected(String clientInfo) {
        Platform.runLater(() -> {
            clientCounter++;
            String clientId = String.format("Client %04d", clientCounter);
            ClientEntry entry = new ClientEntry(clientId, clientInfo, true);
            clientEntries.put(clientInfo, entry);
            clientListView.getItems().add(entry);
            updateClientCount();
            log("New client connected: " + clientId + " - " + clientInfo);
        });
    }
    
    /**
     * Updates a client's status to disconnected.
     * @param clientInfo The client's connection information (IP:PORT)
     */
    public void clientDisconnected(String clientInfo) {
        Platform.runLater(() -> {
            ClientEntry entry = clientEntries.get(clientInfo);
            if (entry != null) {
                entry.connected = false;
                clientListView.refresh();
                updateClientCount();
                log("Client disconnected: " + entry.id + " - " + clientInfo);
            }
        });
    }
    
    /**
     * Updates the connected client count label.
     */
    private void updateClientCount() {
        long connectedCount = clientListView.getItems().stream()
            .filter(entry -> entry.connected)
            .count();
        clientCountLabel.setText("Connected Clients: " + connectedCount);
    }
    
    /**
     * Adds a timestamped log message to the log view.
     * @param message The message to log
     */
    public void log(String message) {
        Platform.runLater(() -> {
            String timestampedMessage = String.format("[%s] %s", 
                LocalTime.now().toString(), 
                message);
            logView.getItems().add(timestampedMessage);
            logView.scrollTo(logView.getItems().size() - 1);
        });
    }
    
    /**
     * Updates the server status label.
     * @param status The new status message
     */
    public void setServerStatus(String status) {
        Platform.runLater(() -> {
            statusLabel.setText("Server Status: " + status);
            log("Server status changed to: " + status);
        });
    }
}