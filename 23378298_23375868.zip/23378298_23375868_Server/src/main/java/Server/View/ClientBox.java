package Server.View;

import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;

/**
 * Custom UI component for displaying client connection information
 * with connection status and disconnect capability.
 */
public class ClientBox extends HBox {
    private final String clientId;
    private final Label statusLabel;
    private final Button disconnectBtn;
    
    /**
     * Creates a new ClientBox to display client connection information.
     * 
     * @param clientId The unique client identifier (e.g., "Client 0001")
     * @param clientInfo The client connection information (IP:Port)
     * @param connected Initial connection status
     * @param onDisconnect Callback to execute when disconnect button is clicked
     */
    public ClientBox(String clientId, String clientInfo, boolean connected, Runnable onDisconnect) {
        this.clientId = clientId;
        
        // Create UI elements
        Label idLabel = new Label(clientId + ": ");
        idLabel.setStyle("-fx-font-weight: bold;");
        
        Label infoLabel = new Label(clientInfo);
        statusLabel = new Label(connected ? "CONNECTED" : "DISCONNECTED");
        statusLabel.setStyle(connected ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
        
        disconnectBtn = new Button("Disconnect");
        disconnectBtn.setVisible(connected);
        disconnectBtn.setStyle("-fx-base: #d9534f; -fx-text-fill: white;");
        disconnectBtn.setOnAction(e -> onDisconnect.run());
        
        // Layout configuration
        this.setSpacing(10);
        this.setPadding(new Insets(5));
        this.setStyle("-fx-border-color: lightgray; -fx-border-width: 1; -fx-background-color: #f9f9f9;");
        this.getChildren().addAll(idLabel, infoLabel, statusLabel, disconnectBtn);
    }
    
    /**
     * Updates the box to show disconnected status.
     */
    public void setDisconnected() {
        Platform.runLater(() -> {
            statusLabel.setText("DISCONNECTED");
            statusLabel.setStyle("-fx-text-fill: red;");
            disconnectBtn.setVisible(false);
        });
    }
    
    /**
     * Gets the client ID for this box.
     * @return The client identifier string
     */
    public String getClientId() {
        return clientId;
    }
    
    /**
     * Gets the client information string.
     * @return The client connection info (IP:Port)
     */
    public String getClientInfo() {
        return ((Label)this.getChildren().get(1)).getText();
    }
    
    /**
     * Checks if the client is currently connected.
     * @return true if connected, false otherwise
     */
    public boolean isConnected() {
        return statusLabel.getText().equals("CONNECTED");
    }
}