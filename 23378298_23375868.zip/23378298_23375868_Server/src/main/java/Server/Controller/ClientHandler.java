package Server.Controller;

import Server.Model.IncorrectActionException;
import Server.Model.EventListSaver;
import Server.Model.Event;
import Server.Model.EventList;
import Server.View.ServerStatusView;
import javafx.concurrent.Task;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Handles communication between the server and a connected client.
 * Processes client commands related to event management.
 */
public class ClientHandler implements Runnable {
    private final EventListSaver saver;
    private final String saveFilePath;
    private final Socket clientSocket;
    private final EventList eventList;
    private final ServerStatusView statusView;
    private final String clientInfo;
    private volatile boolean running = true;
    private PrintWriter out;

    /**
     * Constructs a new ClientHandler.
     *
     * @param clientSocket the socket for client communication
     * @param eventList the event list to manage
     * @param saver the event list saver instance
     * @param saveFilePath the file path for saving events
     * @param statusView the server status view for logging
     * @param clientInfo the client's connection information (IP:PORT)
     */
    public ClientHandler(Socket clientSocket, EventList eventList,
                        EventListSaver saver, String saveFilePath,
                        ServerStatusView statusView, String clientInfo) {
        this.clientSocket = clientSocket;
        this.eventList = eventList;
        this.saver = saver;
        this.saveFilePath = saveFilePath;
        this.statusView = statusView;
        this.clientInfo = clientInfo;
    }

    /**
     * Immediately disconnects the client
     * @throws IOException if there's an error closing the connection
     */
    public void disconnect() throws IOException {
        running = false;
        if (out != null) {
            out.println("SERVER_DISCONNECT");
            out.flush();
        }
        if (!clientSocket.isClosed()) {
            clientSocket.close();
        }
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter writer = new PrintWriter(
                clientSocket.getOutputStream(), true)) {
            
            this.out = writer;
            statusView.log("Client connected: " + clientInfo);

            String inputLine;
            while (running && (inputLine = in.readLine()) != null) {
                if (inputLine.equalsIgnoreCase("STOP")) {
                    out.println("TERMINATE");
                    break;
                }
                String response = processCommand(inputLine, out);
                if (running) {  // Only send response if still connected
                    out.println(response);
                }
            }
        } catch (Exception e) {
            if (running) {  // Only log if we didn't intentionally disconnect
                statusView.log("Client handler error for " + clientInfo + ": " + e.getMessage());
            }
        } finally {
            try {
                if (!clientSocket.isClosed()) {
                    clientSocket.close();
                }
                LectureSchedulerServer.removeClient(clientInfo);
                statusView.clientDisconnected(clientInfo);
                statusView.log("Client disconnected: " + clientInfo);
            } catch (Exception e) {
                statusView.log("Error closing client socket for " + clientInfo + ": " + e.getMessage());
            }
        }
    }

    private String processCommand(String command, PrintWriter out) {
        String[] parts = command.split("\\|");
        String action = parts[0].toUpperCase();
        
        try {
            switch (action) {
                case "ADD":
                    return handleAddCommand(parts);
                case "REMOVE":
                    return handleRemoveCommand(parts);
                case "LOAD_CSV":
                    return handleLoadCsvCommand(out);
                case "DISPLAY":
                    return handleDisplayCommand();
                case "EARLY_LECTURES":
                    return handleEarlyLecturesCommand();
                default:
                    throw new IncorrectActionException("Unknown command: " + action);
            }
        } catch (IncorrectActionException e) {
            statusView.log("Command error from " + clientInfo + ": " + e.getMessage());
            return "ERROR: " + e.getMessage();
        } catch (Exception e) {
            statusView.log("Processing error from " + clientInfo + ": " + e.getMessage());
            return "ERROR: " + e.getMessage();
        }
    }

    private String handleAddCommand(String[] parts) throws Exception {
        if (parts.length != 8) {
            throw new IncorrectActionException(
                "ADD command requires 7 parameters (name|start|end|location|module|type|lecturer)");
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String name = parts[1].trim();
        LocalDateTime startTime = LocalDateTime.parse(parts[2].trim(), formatter);
        LocalDateTime endTime = LocalDateTime.parse(parts[3].trim(), formatter);
        String location = parts[4].trim();
        String module = parts[5].trim();
        String type = parts[6].trim();
        String lecturer = parts[7].trim();

        Event newEvent = new Event(name, startTime, endTime, 
                                 location, module, type, lecturer);
        eventList.add(newEvent);
        saver.save(eventList.arrayList(), saveFilePath);
        
        statusView.log("Added event from " + clientInfo + ": " + newEvent);
        return "Event added: " + newEvent;
    }

    private String handleRemoveCommand(String[] parts) throws Exception {
        if (parts.length != 3) {
            throw new IncorrectActionException(
                "REMOVE command requires 2 parameters (name|startTime)");
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String name = parts[1].trim();
        LocalDateTime startTime = LocalDateTime.parse(parts[2].trim(), formatter);

        ArrayList<Event> events = eventList.alleventswithstarttime(startTime);
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(name)) {
                eventList.remove(event);
                saver.save(eventList.arrayList(), saveFilePath);
                statusView.log("Removed event by " + clientInfo + ": " + event);
                return "Event removed: " + event;
            }
        }
        return "ERROR: Event not found";
    }

    private String handleLoadCsvCommand(PrintWriter out) throws Exception {
        ArrayList<Event> events = eventList.arrayList();
        for (Event event : events) {
            String line = String.join(",",
                event.getName(),
                event.getStartTime().toString(),
                event.getEndTime().toString(),
                event.getLocation(),
                event.getModule(),
                event.getType(),
                event.getLecturer()
            );
            out.println(line);
        }
        return "END_CSV";
    }

    private String handleDisplayCommand() {
        ArrayList<Event> events = eventList.arrayList();
        if (events.isEmpty()) {
            return "No events scheduled";
        }
        return EventList.sortList(events).toString();
    }

    private String handleEarlyLecturesCommand() {
        Task<Void> earlyTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                statusView.log(clientInfo + " initiated early lectures processing...");
                eventList.shiftToEarlyLectures();
                saver.save(eventList.arrayList(), saveFilePath);
                statusView.log("Early lectures processing completed for " + clientInfo);
                return null;
            }
        };

        earlyTask.setOnSucceeded(e -> {
            statusView.log("Lectures successfully shifted to morning times for " + clientInfo);
        });

        earlyTask.setOnFailed(e -> {
            statusView.log("Failed to shift lectures for " + clientInfo + ": " + 
                earlyTask.getException().getMessage());
        });

        LectureSchedulerServer.getForkJoinPool().submit(earlyTask);
        return "Lectures are being shifted to morning times. Please refresh your view.";
    }
}