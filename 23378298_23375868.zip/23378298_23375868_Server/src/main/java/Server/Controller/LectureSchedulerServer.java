package Server.Controller;

import Server.Model.EventListSaver;
import Server.Model.EventList;
import Server.View.ServerStatusView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;

public class LectureSchedulerServer extends Application {
    public static final int PORT = 12345;
    private static final String SAVE_FILE = "events.csv";
    private static ServerStatusView statusView;
    private static ExecutorService threadPool = Executors.newCachedThreadPool();
    private static volatile boolean isRunning = true;
    private static ForkJoinPool forkJoinPool = new ForkJoinPool();
    
    // Track active client handlers
    private static ConcurrentMap<String, ClientHandler> activeClientHandlers = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        statusView = new ServerStatusView();
        statusView.start(primaryStage);
        
        Task<Void> serverTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                startServer();
                return null;
            }
        };
        
        serverTask.setOnFailed(e -> {
            statusView.log("Server crashed: " + serverTask.getException().getMessage());
            stopServer();
        });
        
        new Thread(serverTask).start();
    }

    private void startServer() {
        EventList eventList = new EventList();
        EventListSaver saver = new EventListSaver();
        
        try {
            eventList.setArrayList(saver.load(SAVE_FILE));
            Platform.runLater(() -> statusView.log("Loaded saved events"));
        } catch (IOException e) {
            Platform.runLater(() -> statusView.log("Failed to load events: " + e.getMessage()));
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            Platform.runLater(() -> {
                statusView.setServerStatus("Running on port " + PORT);
                statusView.log("Server started successfully");
            });
            
            while (isRunning) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    String clientInfo = clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort();
                    
                    ClientHandler handler = new ClientHandler(
                        clientSocket, 
                        eventList, 
                        saver, 
                        SAVE_FILE, 
                        statusView,
                        clientInfo
                    );
                    
                    activeClientHandlers.put(clientInfo, handler);
                    threadPool.execute(handler);
                    
                    Platform.runLater(() -> {
                        statusView.clientConnected(clientInfo);
                        statusView.log("New client connected: " + clientInfo);
                    });
                } catch (IOException e) {
                    if (isRunning) {
                        Platform.runLater(() -> statusView.log("Error accepting client connection: " + e.getMessage()));
                    }
                }
            }
        } catch (Exception e) {
            Platform.runLater(() -> statusView.log("Server error: " + e.getMessage()));
        } finally {
            try {
                saver.save(eventList.arrayList(), SAVE_FILE);
                Platform.runLater(() -> statusView.log("Events saved before shutdown"));
            } catch (IOException e) {
                Platform.runLater(() -> statusView.log("Failed to save events: " + e.getMessage()));
            }
        }
    }

    /**
     * Disconnects a specific client immediately
     * @param clientInfo The client info string (IP:PORT)
     */
    public static void disconnectClient(String clientInfo) {
        ClientHandler handler = activeClientHandlers.get(clientInfo);
        if (handler != null) {
            try {
                handler.disconnect();
                activeClientHandlers.remove(clientInfo);
                Platform.runLater(() -> {
                    statusView.clientDisconnected(clientInfo);
                    statusView.log("Manually disconnected client: " + clientInfo);
                });
            } catch (IOException e) {
                Platform.runLater(() -> 
                    statusView.log("Error disconnecting client: " + e.getMessage())
                );
            }
        }
    }

    /**
     * Removes a client from active clients map when they disconnect naturally
     * @param clientInfo The client info string (IP:PORT)
     */
    public static void removeClient(String clientInfo) {
        activeClientHandlers.remove(clientInfo);
    }

    public static void stopServer() {
        isRunning = false;
        // Disconnect all active clients
        activeClientHandlers.forEach((info, handler) -> {
            try {
                handler.disconnect();
            } catch (IOException e) {
                statusView.log("Error closing client socket during shutdown: " + e.getMessage());
            }
        });
        activeClientHandlers.clear();
        threadPool.shutdown();
        forkJoinPool.shutdown();
        Platform.exit();
    }

    public static ForkJoinPool getForkJoinPool() {
        return forkJoinPool;
    }
}