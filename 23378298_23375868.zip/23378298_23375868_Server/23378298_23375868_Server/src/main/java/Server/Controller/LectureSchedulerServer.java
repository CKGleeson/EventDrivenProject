package Server.Controller;

import Server.Model.EventListSaver;
import Server.Model.EventList;
import Server.View.ServerStatusView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;

public class LectureSchedulerServer extends Application {
    public static final int PORT = 12345;
    private static final String SAVE_FILE = "events.csv";
    private static ServerStatusView statusView;
    private static ExecutorService threadPool = Executors.newCachedThreadPool();
    private static volatile boolean isRunning = true;
    private static ForkJoinPool forkJoinPool = new ForkJoinPool();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        statusView = new ServerStatusView();
        statusView.start(primaryStage);
        
        Task<Void> serverTask = new Task<>() {
            @Override
            protected Void call() throws Exception {
                startServer();
                return null;
            }
        };
        
        serverTask.setOnFailed(e -> {
            statusView.log("Server crashed: " + serverTask.getException().getMessage());
            stopServer();
        });
        
        new Thread(serverTask).start();
    }

    private void startServer() {
        EventList eventList = new EventList();
        EventListSaver saver = new EventListSaver();
        
        try {
            eventList.setArrayList(saver.load(SAVE_FILE));
            Platform.runLater(() -> statusView.log("Loaded saved events"));
        } catch (IOException e) {
            Platform.runLater(() -> statusView.log("Failed to load events: " + e.getMessage()));
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            Platform.runLater(() -> {
                statusView.setServerStatus("Running on port " + PORT);
                statusView.log("Server started successfully");
            });
            
            while (isRunning) {
                Socket clientSocket = serverSocket.accept();
                String clientInfo = clientSocket.getInetAddress().toString();
                
                Platform.runLater(() -> {
                    statusView.clientConnected(clientInfo);
                    statusView.log("New client connected: " + clientInfo);
                });
                
                ClientHandler handler = new ClientHandler(clientSocket, eventList, saver, SAVE_FILE, statusView);
                threadPool.execute(handler);
            }
        } catch (Exception e) {
            Platform.runLater(() -> statusView.log("Server error: " + e.getMessage()));
        } finally {
            try {
                saver.save(eventList.arrayList(), SAVE_FILE);
                Platform.runLater(() -> statusView.log("Events saved before shutdown"));
            } catch (IOException e) {
                Platform.runLater(() -> statusView.log("Failed to save events: " + e.getMessage()));
            }
        }
    }

    public static void stopServer() {
        isRunning = false;
        threadPool.shutdown();
        forkJoinPool.shutdown();
        Platform.exit();
    }

    public static ForkJoinPool getForkJoinPool() {
        return forkJoinPool;
    }
}