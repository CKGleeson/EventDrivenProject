package Server.Controller;

import Server.Model.IncorrectActionException;
import Server.Model.EventListSaver;
import Server.Model.Event;
import Server.Model.EventList;
import Server.View.ServerStatusView;
import javafx.concurrent.Task;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Handles communication between the server and a connected client.
 * Processes client commands related to event management.
 */
public class ClientHandler implements Runnable {
    private EventListSaver saver;
    private String saveFilePath;
    private Socket clientSocket;
    private EventList eventList;
    private ServerStatusView statusView;

    /**
     * Constructs a new ClientHandler.
     *
     * @param clientSocket the socket for client communication
     * @param eventList the event list to manage
     * @param saver the event list saver instance
     * @param saveFilePath the file path for saving events
     * @param statusView the server status view for logging
     */
    public ClientHandler(Socket clientSocket, EventList eventList, 
                        EventListSaver saver, String saveFilePath, 
                        ServerStatusView statusView) {
        this.clientSocket = clientSocket;
        this.eventList = eventList;
        this.saver = saver;
        this.saveFilePath = saveFilePath;
        this.statusView = statusView;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter out = new PrintWriter(
                clientSocket.getOutputStream(), true)) {
            
            statusView.log("Client connected: " + 
                clientSocket.getInetAddress().getHostAddress());

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.equalsIgnoreCase("STOP")) {
                    out.println("TERMINATE");
                    break;
                }
                String response = processCommand(inputLine, out);
                out.println(response);
            }
        } catch (Exception e) {
            statusView.log("Client handler error: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
                statusView.log("Client disconnected: " + 
                    clientSocket.getInetAddress().getHostAddress());
            } catch (Exception e) {
                statusView.log("Error closing client socket: " + e.getMessage());
            }
        }
    }

    /**
     * Processes a command from the client.
     * 
     * @param command the command string
     * @param out the output writer for streaming responses
     * @return the response to send back to the client
     */
    private String processCommand(String command, PrintWriter out) {
        String[] parts = command.split("\\|");
        String action = parts[0].toUpperCase();
        
        try {
            switch (action) {
                case "ADD":
                    return handleAddCommand(parts);
                case "REMOVE":
                    return handleRemoveCommand(parts);
                case "LOAD_CSV":
                    return handleLoadCsvCommand(out);
                case "DISPLAY":
                    return handleDisplayCommand();
                case "EARLY_LECTURES":
                    return handleEarlyLecturesCommand();
                default:
                    throw new IncorrectActionException("Unknown command: " + action);
            }
        } catch (IncorrectActionException e) {
            statusView.log("Command error: " + e.getMessage());
            return "ERROR: " + e.getMessage();
        } catch (Exception e) {
            statusView.log("Processing error: " + e.getMessage());
            return "ERROR: " + e.getMessage();
        }
    }

    private String handleAddCommand(String[] parts) throws Exception {
        if (parts.length != 8) {
            throw new IncorrectActionException(
                "ADD command requires 7 parameters (name|start|end|location|module|type|lecturer)");
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String name = parts[1].trim();
        LocalDateTime startTime = LocalDateTime.parse(parts[2].trim(), formatter);
        LocalDateTime endTime = LocalDateTime.parse(parts[3].trim(), formatter);
        String location = parts[4].trim();
        String module = parts[5].trim();
        String type = parts[6].trim();
        String lecturer = parts[7].trim();

        Event newEvent = new Event(name, startTime, endTime, 
                                 location, module, type, lecturer);
        eventList.add(newEvent);
        saver.save(eventList.arrayList(), saveFilePath);
        
        statusView.log("Added event: " + newEvent);
        return "Event added: " + newEvent;
    }

    private String handleRemoveCommand(String[] parts) throws Exception {
        if (parts.length != 3) {
            throw new IncorrectActionException(
                "REMOVE command requires 2 parameters (name|startTime)");
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String name = parts[1].trim();
        LocalDateTime startTime = LocalDateTime.parse(parts[2].trim(), formatter);

        ArrayList<Event> events = eventList.alleventswithstarttime(startTime);
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(name)) {
                eventList.remove(event);
                saver.save(eventList.arrayList(), saveFilePath);
                statusView.log("Removed event: " + event);
                return "Event removed: " + event;
            }
        }
        return "ERROR: Event not found";
    }

    private String handleLoadCsvCommand(PrintWriter out) throws Exception {
        ArrayList<Event> events = eventList.arrayList();
        for (Event event : events) {
            String line = String.join(",",
                event.getName(),
                event.getStartTime().toString(),
                event.getEndTime().toString(),
                event.getLocation(),
                event.getModule(),
                event.getType(),
                event.getLecturer()
            );
            out.println(line);
        }
        return "END_CSV";
    }

    private String handleDisplayCommand() {
        ArrayList<Event> events = eventList.arrayList();
        if (events.isEmpty()) {
            return "No events scheduled";
        }
        return EventList.sortList(events).toString();
    }

    private String handleEarlyLecturesCommand() {
        Task<Void> earlyTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                statusView.log("Starting early lectures processing...");
                eventList.shiftToEarlyLectures();
                saver.save(eventList.arrayList(), saveFilePath);
                statusView.log("Early lectures processing completed");
                return null;
            }
        };

        earlyTask.setOnSucceeded(e -> {
            statusView.log("Lectures successfully shifted to morning times");
        });

        earlyTask.setOnFailed(e -> {
            statusView.log("Failed to shift lectures: " + 
                earlyTask.getException().getMessage());
        });

        LectureSchedulerServer.getForkJoinPool().submit(earlyTask);
        return "Lectures are being shifted to morning times. Please refresh your view.";
    }
}