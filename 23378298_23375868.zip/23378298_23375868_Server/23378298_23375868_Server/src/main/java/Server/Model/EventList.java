package Server.Model;

import Server.Controller.LectureSchedulerServer;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.locks.ReentrantLock;

public class EventList {
    private ArrayList<Event> eventList = new ArrayList<>();
    private final ReentrantLock lock = new ReentrantLock();

    /**
     * Adds an event to the list after checking for time conflicts.
     * @param event The event to be added
     * @throws IllegalArgumentException if there's a time overlap
     */
    public void add(Event event) {
        lock.lock();
        try {
            ArrayList<Event> eventsOnSameDate = alleventsondate(event.getStartTime().toLocalDate());
            for (Event existingEvent : eventsOnSameDate) {
                if (event.getStartTime().isBefore(existingEvent.getEndTime()) &&
                    event.getEndTime().isAfter(existingEvent.getStartTime())) {
                    throw new IllegalArgumentException("Event time conflict with: " + existingEvent);
                }
            }
            eventList.add(event);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Removes an event from the list.
     * @param event The event to be removed
     * @throws IllegalArgumentException if the event is not found
     */
    public void remove(Event event) {
        lock.lock();
        try {
            if (!eventList.remove(event)) {
                throw new IllegalArgumentException("Event not found: " + event);
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns a copy of all events.
     * @return A list containing all events
     */
    public ArrayList<Event> arrayList() {
        lock.lock();
        try {
            return new ArrayList<>(eventList);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Replaces the current list of events.
     * @param events The new list of events
     */
    public void setArrayList(ArrayList<Event> events) {
        lock.lock();
        try {
            eventList = events;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Gets all events on a specific date.
     * @param date The target date
     * @return List of events on that date
     */
    public ArrayList<Event> alleventsondate(LocalDate date) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getStartTime().toLocalDate().equals(date)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific name.
     * @param name The name to search for
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithname(String name) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getName().equalsIgnoreCase(name)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific start time.
     * @param startTime The start time to match
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithstarttime(LocalDateTime startTime) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getStartTime().equals(startTime)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific location.
     * @param location The location to search for
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithlocation(String location) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getLocation().equalsIgnoreCase(location)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific module.
     * @param module The module to search for
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithmodule(String module) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getModule().equalsIgnoreCase(module)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific type.
     * @param type The event type to search for
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithtype(String type) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getType().equalsIgnoreCase(type)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Gets events with a specific lecturer.
     * @param lecturer The lecturer to search for
     * @return List of matching events
     */
    public ArrayList<Event> alleventswithlecturer(String lecturer) {
        ArrayList<Event> events = new ArrayList<>();
        lock.lock();
        try {
            for (Event event : eventList) {
                if (event.getLecturer().equalsIgnoreCase(lecturer)) {
                    events.add(event);
                }
            }
        } finally {
            lock.unlock();
        }
        return events;
    }

    /**
     * Sorts a list of events chronologically.
     * @param events The list to sort
     * @return A new sorted list
     */
    public static ArrayList<Event> sortList(ArrayList<Event> events) {
        ArrayList<Event> sorted = new ArrayList<>(events);
        Collections.sort(sorted, (e1, e2) -> 
            e1.getStartTime().compareTo(e2.getStartTime()));
        return sorted;
    }

    /**
     * Shifts lectures to morning time slots (9:00-13:00).
     * Uses Fork-Join for parallel processing by day.
     */
    public void shiftToEarlyLectures() {
        lock.lock();
        try {
            List<LocalDate> dates = getUniqueDates();
            ShiftLecturesTask task = new ShiftLecturesTask(dates, this);
            LectureSchedulerServer.getForkJoinPool().invoke(task);
        } finally {
            lock.unlock();
        }
    }

    private List<LocalDate> getUniqueDates() {
        List<LocalDate> dates = new ArrayList<>();
        lock.lock();
        try {
            for (Event e : eventList) {
                LocalDate date = e.getStartTime().toLocalDate();
                if (!dates.contains(date)) {
                    dates.add(date);
                }
            }
        } finally {
            lock.unlock();
        }
        return dates;
    }

    private static class ShiftLecturesTask extends RecursiveAction {
        private final List<LocalDate> dates;
        private final EventList eventList;

        public ShiftLecturesTask(List<LocalDate> dates, EventList eventList) {
            this.dates = dates;
            this.eventList = eventList;
        }

        @Override
        protected void compute() {
            if (dates.size() <= 1) {
                dates.forEach(date -> eventList.processDay(date));
            } else {
                int mid = dates.size() / 2;
                ShiftLecturesTask leftTask = new ShiftLecturesTask(
                    dates.subList(0, mid), eventList);
                ShiftLecturesTask rightTask = new ShiftLecturesTask(
                    dates.subList(mid, dates.size()), eventList);
                invokeAll(leftTask, rightTask);
            }
        }
    }

    private void processDay(LocalDate date) {
        List<Event> lectures = getLecturesForDay(date);
        if (lectures.isEmpty()) return;

        Collections.sort(lectures, (e1, e2) -> 
            e1.getStartTime().compareTo(e2.getStartTime()));

        LocalDateTime currentStart = date.atTime(9, 0); // Start at 9:00 AM
        LocalDateTime lunchStart = date.atTime(13, 0);  // End at 1:00 PM

        for (Event lecture : lectures) {
            long duration = lecture.getDurationMinutes();
            LocalDateTime newStart = currentStart;
            LocalDateTime newEnd = newStart.plusMinutes(duration);

            if (newEnd.isAfter(lunchStart)) {
                continue; // Skip if it would go past lunch
            }

            if (isTimeSlotAvailable(newStart, newEnd, date)) {
                lecture.setStartTime(newStart);
                lecture.setEndTime(newEnd);
                currentStart = newEnd;
            }
        }
    }

    private List<Event> getLecturesForDay(LocalDate date) {
        List<Event> lectures = new ArrayList<>();
        lock.lock();
        try {
            for (Event e : eventList) {
                if (e.getStartTime().toLocalDate().equals(date) && 
                    "Lecture".equalsIgnoreCase(e.getType())) {
                    lectures.add(e);
                }
            }
        } finally {
            lock.unlock();
        }
        return lectures;
    }

    private boolean isTimeSlotAvailable(LocalDateTime start, 
                                      LocalDateTime end, 
                                      LocalDate date) {
        List<Event> events = alleventsondate(date);
        for (Event e : events) {
            if (e.getStartTime().isBefore(end) && 
                e.getEndTime().isAfter(start)) {
                return false;
            }
        }
        return true;
    }
}