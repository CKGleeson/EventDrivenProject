package Server.Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a scheduled event such as a lecture, lab, or tutorial.
 * Contains details about the event's name, time, location, associated module, type, and lecturer.
 */
public class Event {
    private String name;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String location;
    private String module;
    private String type; // "Lecture", "Lab", or "Tutorial"
    private String lecturer;

    /**
     * Constructs an Event with specified details.
     *
     * @param name       the name/title of the event
     * @param startTime  the start date and time of the event
     * @param endTime    the end date and time of the event
     * @param location   the physical/virtual location of the event
     * @param module     the academic module associated with the event
     * @param type       the type of event ("Lecture", "Lab", or "Tutorial")
     * @param lecturer   the name of the lecturer/instructor
     */
    public Event(String name, LocalDateTime startTime, LocalDateTime endTime, 
                String location, String module, String type, String lecturer) {
        this.name = name;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
        this.module = module;
        this.type = type;
        this.lecturer = lecturer;
    }

    // Getters and Setters

    public String getName() { 
        return name; 
    }

    public void setName(String name) { 
        this.name = name; 
    }

    public LocalDateTime getStartTime() { 
        return startTime; 
    }

    public void setStartTime(LocalDateTime startTime) { 
        this.startTime = startTime; 
    }

    public LocalDateTime getEndTime() { 
        return endTime; 
    }

    public void setEndTime(LocalDateTime endTime) { 
        this.endTime = endTime; 
    }

    public String getLocation() { 
        return location; 
    }

    public void setLocation(String location) { 
        this.location = location; 
    }

    public String getModule() { 
        return module; 
    }

    public void setModule(String module) { 
        this.module = module; 
    }

    public String getType() { 
        return type; 
    }

    public void setType(String type) { 
        this.type = type; 
    }

    public String getLecturer() { 
        return lecturer; 
    }

    public void setLecturer(String lecturer) { 
        this.lecturer = lecturer; 
    }

    /**
     * Calculates the duration of the event in minutes.
     * @return duration in minutes
     */
    public long getDurationMinutes() {
        return java.time.Duration.between(startTime, endTime).toMinutes();
    }

    /**
     * Extracts the date portion from the event's start time.
     * @return the date as a string in ISO-8601 format (YYYY-MM-DD)
     */
    public String getDate() {
        return startTime.toLocalDate().toString();
    }

    /**
     * Formats the time range of the event.
     * @return formatted time string (HH:MM - HH:MM)
     */
    public String getFormattedTime() {
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
        return startTime.format(timeFormat) + " - " + endTime.format(timeFormat);
    }

    /**
     * Formats the event details for display.
     * @return formatted details string
     */
    public String getFormattedDetails() {
        return String.format("%s | %s | %s", module, location, lecturer);
    }

    /**
     * Returns a formatted string representation of the event.
     * @return a string in the format: 
     * "Event: [name], Date: [date], Time: [start]-[end], Module: [module], 
     *  Location: [location], Type: [type], Lecturer: [lecturer]"
     */
    @Override
    public String toString() {
        return String.format("Event: %s, Date: %s, Time: %s - %s, Module: %s, "
                + "Location: %s, Type: %s, Lecturer: %s",
                name, getDate(), startTime.toLocalTime(), endTime.toLocalTime(),
                module, location, type, lecturer);
    }
}