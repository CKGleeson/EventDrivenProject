package Server.View;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import java.time.LocalTime;

/**
 * The GUI view for displaying server status and logs.
 */
public class ServerStatusView {
    private Stage primaryStage;
    private ListView<String> logView = new ListView<>();
    private ListView<String> clientList = new ListView<>(FXCollections.observableArrayList());
    private Label statusLabel = new Label("Server Status: Not Running");
    private Button closeButton = new Button("Close Server");

    /**
     * Starts and displays the server status window.
     * @param stage The primary stage for the application
     */
    public void start(Stage stage) {
        primaryStage = stage;
        setupUI();
        setupEventHandlers();
        
        Scene scene = new Scene(createRootLayout(), 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Lecture Scheduler Server Console");
        primaryStage.show();
    }

    private void setupUI() {
        logView.setPrefHeight(400);
        clientList.setPrefHeight(150);
        statusLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        closeButton.setStyle("-fx-base: #d9534f; -fx-text-fill: white;");
    }

    private VBox createRootLayout() {
        VBox root = new VBox(10);
        root.setPadding(new javafx.geometry.Insets(15));
        root.getChildren().addAll(
            statusLabel,
            new Label("Connected Clients:"),
            clientList,
            new Label("Server Log:"),
            logView,
            closeButton
        );
        return root;
    }

    private void setupEventHandlers() {
        closeButton.setOnAction(e -> shutdownServer());
        primaryStage.setOnCloseRequest(this::handleWindowClose);
    }

    private void handleWindowClose(WindowEvent event) {
        event.consume(); // Prevent immediate closing
        shutdownServer();
    }

    private void shutdownServer() {
        Platform.runLater(() -> {
            log("Server shutdown initiated");
            statusLabel.setText("Server Status: Shutting down...");
        });
        Platform.exit();
        System.exit(0);
    }
    
    /**
     * Adds a new client to the connected clients list.
     * @param clientInfo The client's connection information
     */
    public void clientConnected(String clientInfo) {
        Platform.runLater(() -> {
            clientList.getItems().add(clientInfo);
            log("New client connected: " + clientInfo);
        });
    }
    
    /**
     * Adds a timestamped log message to the log view.
     * @param message The message to log
     */
    public void log(String message) {
        Platform.runLater(() -> {
            String timestampedMessage = String.format("[%s] %s", 
                LocalTime.now().toString(), 
                message);
            logView.getItems().add(timestampedMessage);
            // Auto-scroll to bottom
            logView.scrollTo(logView.getItems().size() - 1);
        });
    }
    
    /**
     * Updates the server status label.
     * @param status The new status message
     */
    public void setServerStatus(String status) {
        Platform.runLater(() -> {
            statusLabel.setText("Server Status: " + status);
            log("Server status changed to: " + status);
        });
    }

    /**
     * Removes a client from the connected clients list.
     * @param clientInfo The client's connection information
     */
    public void clientDisconnected(String clientInfo) {
        Platform.runLater(() -> {
            clientList.getItems().remove(clientInfo);
            log("Client disconnected: " + clientInfo);
        });
    }
}